#!/bin/bash
#Shell Script to Run Main Class ReadTextFile.java from relative path of working directory src
java -cp ./InsightData.jar ReadTextFile

#javac -sourcePath ./src ReadTextFile.java
#java -sourcePath ./src/ ReadTextFile